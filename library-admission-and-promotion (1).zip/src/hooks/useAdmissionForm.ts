import { useMemo, useState } from "react";
import { CONTACT, PLANS } from "@/data";

export type PlanId = "A" | "B" | "C";

export interface AdmissionFormData {
  fullName: string;
  contactNumber: string;
  email: string;
  guardianName: string;
  plan: "" | PlanId;
  seatNumber: number | null;
  idType: "" | "Government ID" | "Student ID";
  idNumber: string;
  startDate: string;
  address: string;
  city: string;
}

const INITIAL: AdmissionFormData = {
  fullName: "",
  contactNumber: "",
  email: "",
  guardianName: "",
  plan: "",
  seatNumber: null,
  idType: "",
  idNumber: "",
  startDate: "",
  address: "",
  city: "",
};

export function useAdmissionForm() {
  const [form, setForm] = useState<AdmissionFormData>(INITIAL);
  const [submittedChannel, setSubmittedChannel] = useState<
    "whatsapp" | "gmail" | "both" | null
  >(null);
  const [isOpen, setIsOpen] = useState(false);

  const update = (patch: Partial<AdmissionFormData>) =>
    setForm((prev) => ({ ...prev, ...patch }));

  const openForm = (preferredPlan?: PlanId) => {
    if (preferredPlan) {
      update({ plan: preferredPlan });
    }
    setIsOpen(true);
  };

  const closeForm = () => {
    setIsOpen(false);
  };

  const reset = () => {
    setForm(INITIAL);
    setSubmittedChannel(null);
  };

  const selectedPlan = useMemo(
    () => PLANS.find((p) => p.id === form.plan) ?? null,
    [form.plan]
  );

  const isValid =
    form.fullName.trim().length > 1 &&
    form.contactNumber.trim().length >= 10 &&
    form.plan !== "" &&
    form.seatNumber !== null;

  const whatsappMessage = useMemo(() => {
    if (!selectedPlan || form.seatNumber === null) return "";
    return [
      "Hello Gold Star Self Study Library 👋",
      "I would like to reserve my study seat. Here is my complete Admission Form:",
      "",
      `• Student Name: ${form.fullName}`,
      `• Mobile Number: ${form.contactNumber}`,
      form.email ? `• Student Email: ${form.email}` : "",
      form.guardianName ? `• Guardian Name: ${form.guardianName}` : "",
      `• Membership Plan: ${selectedPlan.name} (${selectedPlan.shift}) — ${selectedPlan.timings}`,
      `• Monthly Fee: ₹${selectedPlan.fee}/month`,
      `• Preferred Seat No.: #${form.seatNumber} (of 55 Seats)`,
      form.idType
        ? `• ID Proof: ${form.idType}${form.idNumber ? ` (${form.idNumber})` : ""}`
        : "",
      form.startDate ? `• Joining Date: ${form.startDate}` : "",
      form.address || form.city
        ? `• Address: ${[form.address, form.city].filter(Boolean).join(", ")}`
        : "",
      "",
      "Please confirm my seat reservation. Thank you!",
    ]
      .filter(Boolean)
      .join("\n");
  }, [selectedPlan, form]);

  const emailSubject = useMemo(() => {
    if (!form.seatNumber)
      return "New Seat Admission Application — Gold Star Self Study Library";
    return `Seat #${form.seatNumber} Admission — ${form.fullName || "Student"} (Plan ${form.plan})`;
  }, [form.seatNumber, form.fullName, form.plan]);

  const emailBody = useMemo(() => {
    if (!selectedPlan || form.seatNumber === null) return "";
    return [
      "GOLD STAR SELF STUDY LIBRARY — ADMISSION FORM SUBMISSION",
      "=========================================================",
      "",
      `Student Full Name : ${form.fullName}`,
      `Contact Mobile    : ${form.contactNumber}`,
      `Email Address     : ${form.email || "N/A"}`,
      `Guardian Name     : ${form.guardianName || "N/A"}`,
      "",
      `Selected Plan     : ${selectedPlan.name} (${selectedPlan.shift})`,
      `Timings           : ${selectedPlan.timings}`,
      `Monthly Fee       : ₹${selectedPlan.fee}/month`,
      `Preferred Seat #  : Seat #${form.seatNumber} (out of 55 seats)`,
      `ID Proof          : ${form.idType || "N/A"} ${form.idNumber ? `— ${form.idNumber}` : ""}`,
      `Joining Date      : ${form.startDate || "Immediate"}`,
      `Address / City    : ${[form.address, form.city].filter(Boolean).join(", ") || "N/A"}`,
      "",
      "Sent via Gold Star Self Study Library Digital Portal.",
    ].join("\n");
  }, [selectedPlan, form]);

  const gmailComposeUrl = useMemo(() => {
    return `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(
      CONTACT.email
    )}&su=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(
      emailBody
    )}`;
  }, [emailSubject, emailBody]);

  const mailtoUrl = useMemo(() => {
    return `mailto:${CONTACT.email}?subject=${encodeURIComponent(
      emailSubject
    )}&body=${encodeURIComponent(emailBody)}`;
  }, [emailSubject, emailBody]);

  return {
    form,
    update,
    reset,
    selectedPlan,
    isValid,
    submittedChannel,
    setSubmittedChannel,
    whatsappMessage,
    emailSubject,
    emailBody,
    gmailComposeUrl,
    mailtoUrl,
    isOpen,
    openForm,
    closeForm,
  };
}
