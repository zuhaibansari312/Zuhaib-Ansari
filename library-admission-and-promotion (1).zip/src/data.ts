export interface Plan {
  id: "A" | "B" | "C";
  name: string;
  shift: string;
  timings: string;
  hours: string;
  fee: number;
  icon: "sun" | "moon" | "sunmoon";
  tagline: string;
  popular?: boolean;
}

export const PLANS: Plan[] = [
  {
    id: "A",
    name: "Plan A",
    shift: "Half Day · Morning",
    timings: "7:00 AM – 2:00 PM",
    hours: "7 hours",
    fee: 500,
    icon: "sun",
    tagline: "Crisp morning focus for early risers",
  },
  {
    id: "B",
    name: "Plan B",
    shift: "Half Day · Evening",
    timings: "2:00 PM – 9:00 PM",
    hours: "7 hours",
    fee: 500,
    icon: "moon",
    tagline: "Quiet evenings for deep concentration",
  },
  {
    id: "C",
    name: "Plan C",
    shift: "Full Day Study",
    timings: "7:00 AM – 9:00 PM",
    hours: "14 hours",
    fee: 900,
    icon: "sunmoon",
    popular: true,
    tagline: "Unlimited access for maximum preparation",
  },
];

export interface Facility {
  title: string;
  description: string;
  icon: "ac" | "wifi" | "chair" | "power" | "silence" | "water";
}

export const FACILITIES: Facility[] = [
  {
    icon: "ac",
    title: "Fully Air Conditioned",
    description:
      "Comfortably cooled rooms designed for long, distraction-free study sessions.",
  },
  {
    icon: "wifi",
    title: "High-Speed Unlimited Wi-Fi",
    description:
      "Uninterrupted connectivity for online lectures, research and e-learning.",
  },
  {
    icon: "chair",
    title: "Ergonomic Premium Seating",
    description:
      "Spacious individual desks and posture-friendly chairs for marathon focus.",
  },
  {
    icon: "power",
    title: "Power Outlet at Every Seat",
    description:
      "Dedicated charging points for laptops, tablets and phones — always ready.",
  },
  {
    icon: "silence",
    title: "Pin-Drop Silence Zone",
    description:
      "A strictly enforced quiet policy so you can enter a state of deep work.",
  },
  {
    icon: "water",
    title: "Clean Water & Washrooms",
    description:
      "Purified drinking water and well-maintained washrooms on the premises.",
  },
];

export const CONTACT = {
  googleSearchName: "Gold Star Library",
  googleSearchUrl: "https://www.google.com/search?q=Gold+Star+Library+Banswara",
  phoneDisplay: "+91 88901 18844",
  phoneRaw: "918890118844",
  phoneCompact: "8890118844",
  email: "kuwait2business@gmail.com",
  totalSeats: 55,
  mapsUrl: "https://maps.app.goo.gl/54NEeJBNaL2eGC4U7",
  address: "Gold Star Self Study Library, Banswara, Rajasthan",
  coordinates: "23.5704925, 74.4409716",
};

export const BOOKED_SEATS: number[] = [4, 9, 15, 22, 27, 33, 38, 44, 50];

export const WHATSAPP_PROMO = `📚 Achieve Your Goals at Gold Star Self Study Library! 🌟

Looking for the perfect disturbance-free environment to ace your upcoming exams? Your search ends here! Gold Star Self Study Library offers a premium, peaceful atmosphere for students & aspirants who want to maximize productivity.

📍 Limited Availability: Only 55 Exclusive Seats (No. 1 – 55). Book your preferred desk before it's gone!

⏱️ Flexible & Affordable Membership Plans
▸ Plan A — 🌅 Half Day Morning — 7:00 AM – 2:00 PM — ₹500/month
▸ Plan B — 🌆 Half Day Evening — 2:00 PM – 9:00 PM — ₹500/month
▸ Plan C — 🚀 Full Day Study — 7:00 AM – 9:00 PM — ₹900/month

💡 World-Class Facilities Included:
❄️ Fully Air Conditioned (AC) rooms
📶 High-Speed Unlimited Wi-Fi
🪑 Ergonomic Premium Chairs & spacious desks
🔌 Dedicated Power Outlets at every seat
🤫 Strict Pin-Drop Silence Zone
💧 Clean Drinking Water & Washrooms

📝 To reserve your seat: Full Name + Contact Number, Selected Plan, Preferred Seat (1–55) and a copy of Govt/Student ID.

📞 Reserve Your Desk Today!
Call / WhatsApp: +91 8890118844
📧 Email: kuwait2business@gmail.com`;

export const SMS_PROMO = `🏆 GOLD STAR SELF STUDY LIBRARY 🏆
Your Private Space for Ultimate Success!

🏢 Total Capacity: 55 Desks Only (Numbered 1–55)
❄️ Amenities: High-Speed Wi-Fi, AC, Charging Points, Pin-Drop Silence, Comfy Seating.

💰 Budget-Friendly Pricing:
Morning Batch (7 AM – 2 PM) — ₹500/month
Evening Batch (2 PM – 9 PM) — ₹500/month
Full-Day Batch (7 AM – 9 PM) — ₹900/month

📝 On-spot admissions open now! Bring your ID proof to select your lucky seat.

📞 Contact Immediately: 8890118844
📧 Email: kuwait2business@gmail.com`;

export const SOCIAL_PROMO = `🌟 Your seat to success is waiting.

Gold Star Self Study Library — 55 exclusive desks with full AC, high-speed Wi-Fi and pin-drop silence.

⏰ Plans from just ₹500/month
🌅 Morning · 7 AM – 2 PM
🌆 Evening · 2 PM – 9 PM
🚀 Full Day · 7 AM – 9 PM

📲 Book your desk today: +91 8890118844
📍 Gold Star Self Study Library

#GoldStarLibrary #SelfStudy #ExamPrep #StudyHard #LibraryNearMe #FocusMode`;

export interface PromoItem {
  id: string;
  label: string;
  badge: string;
  icon: "whatsapp" | "sms" | "social";
  description: string;
  body: string;
}

export const PROMOS: PromoItem[] = [
  {
    id: "whatsapp",
    label: "WhatsApp Broadcast",
    badge: "Recommended",
    icon: "whatsapp",
    description:
      "The premium, emoji-rich broadcast ready to copy-paste straight into WhatsApp.",
    body: WHATSAPP_PROMO,
  },
  {
    id: "sms",
    label: "SMS / Pamphlet",
    badge: "Short & Punchy",
    icon: "sms",
    description:
      "A tight, scannable version perfect for SMS blasts and print pamphlets.",
    body: SMS_PROMO,
  },
  {
    id: "social",
    label: "Instagram / Facebook",
    badge: "Caption + Hashtags",
    icon: "social",
    description:
      "A clean social caption with hashtags to drive engagement on your feed.",
    body: SOCIAL_PROMO,
  },
];
