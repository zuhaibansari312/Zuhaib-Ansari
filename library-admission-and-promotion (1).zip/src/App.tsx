import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Stats from "@/components/Stats";
import About from "@/components/About";
import Pricing from "@/components/Pricing";
import Facilities from "@/components/Facilities";
import AdmissionForm from "@/components/AdmissionForm";
import PrintAdmissionForm from "@/components/PrintAdmissionForm";
import GalleryAndLocation from "@/components/GalleryAndLocation";
import Promos from "@/components/Promos";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import DomainShareModal from "@/components/DomainShareModal";
import { useAdmissionForm } from "@/hooks/useAdmissionForm";

export default function App() {
  const admission = useAdmissionForm();

  return (
    <div className="min-h-screen bg-ink-950 font-sans text-slate-100 antialiased print:bg-white">
      {/* On-screen experience */}
      <div className="print:hidden">
        <Navbar onOpenAdmission={() => admission.openForm()} />
        <main>
          <Hero onOpenAdmission={() => admission.openForm()} />
          <Stats />
          <About />
          <GalleryAndLocation onOpenAdmission={() => admission.openForm()} />
          <Pricing onSelectPlan={(id) => admission.openForm(id)} />
          <Facilities />
          <AdmissionForm
            form={admission.form}
            update={admission.update}
            selectedPlan={admission.selectedPlan}
            isValid={admission.isValid}
            whatsappMessage={admission.whatsappMessage}
            gmailComposeUrl={admission.gmailComposeUrl}
            mailtoUrl={admission.mailtoUrl}
            submittedChannel={admission.submittedChannel}
            setSubmittedChannel={admission.setSubmittedChannel}
            reset={admission.reset}
            isOpen={admission.isOpen}
            onOpen={() => admission.openForm()}
            onClose={admission.closeForm}
          />
          <Promos />
          <Contact onOpenAdmission={() => admission.openForm()} />
        </main>
        <Footer />
        <DomainShareModal />
      </div>

      {/* Print-only clean admission form */}
      <PrintAdmissionForm
        form={admission.form}
        selectedPlan={admission.selectedPlan}
      />
    </div>
  );
}
