import { useEffect, useState } from "react";
import { Menu, Phone, X } from "lucide-react";
import { Logo } from "@/components/Brand";
import { CONTACT } from "@/data";
import { cn } from "@/utils/cn";

const LINKS = [
  { label: "Plans", href: "#plans" },
  { label: "Photos & Map", href: "#gallery" },
  { label: "Facilities", href: "#facilities" },
  { label: "Admission Form", href: "#admission" },
  { label: "Promo Kit", href: "#promos" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar({ onOpenAdmission }: { onOpenAdmission: () => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "border-b border-white/10 bg-ink-950/85 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      )}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3.5 sm:px-8">
        <a href="#top" aria-label="Gold Star Self Study Library home">
          <Logo />
        </a>

        <div className="hidden items-center gap-1 lg:flex">
          {LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="rounded-full px-4 py-2 text-sm font-medium text-slate-300 transition-colors hover:bg-white/5 hover:text-gold-300"
            >
              {link.label}
            </a>
          ))}
        </div>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href={`tel:+${CONTACT.phoneRaw}`}
            className="inline-flex items-center gap-2 text-sm font-medium text-slate-300 transition-colors hover:text-gold-300"
          >
            <Phone className="h-4 w-4 text-gold-400" />
            {CONTACT.phoneDisplay}
          </a>
          <button
            type="button"
            onClick={onOpenAdmission}
            className="rounded-full bg-gold-gradient px-5 py-2.5 text-sm font-bold text-ink-950 shadow-lg shadow-gold-900/30 transition-transform hover:scale-[1.03] cursor-pointer"
          >
            Book a Seat
          </button>
        </div>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 text-white lg:hidden"
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-white/10 bg-ink-950/95 px-5 pb-6 pt-3 backdrop-blur-xl lg:hidden">
          <div className="flex flex-col gap-1">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-3 text-base font-medium text-slate-200 hover:bg-white/5 hover:text-gold-300"
              >
                {link.label}
              </a>
            ))}
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                onOpenAdmission();
              }}
              className="mt-3 rounded-full bg-gold-gradient px-5 py-3 text-center text-base font-bold text-ink-950"
            >
              Book a Seat
            </button>
            <a
              href={`tel:+${CONTACT.phoneRaw}`}
              className="mt-2 inline-flex items-center justify-center gap-2 rounded-full border border-white/10 px-5 py-3 text-base font-medium text-slate-200"
            >
              <Phone className="h-4 w-4 text-gold-400" />
              {CONTACT.phoneDisplay}
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
