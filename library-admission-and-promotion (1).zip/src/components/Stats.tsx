import { Armchair, Clock3, Layers3, Wifi } from "lucide-react";

const STATS = [
  { icon: Armchair, value: "55", label: "Exclusive Seats" },
  { icon: Layers3, value: "3", label: "Flexible Plans" },
  { icon: Clock3, value: "14", label: "Hours Open Daily" },
  { icon: Wifi, value: "100%", label: "AC + Wi-Fi Everywhere" },
];

export default function Stats() {
  return (
    <section className="relative border-y border-white/5 bg-ink-900">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px bg-white/5 sm:grid-cols-4">
        {STATS.map((s) => (
          <div
            key={s.label}
            className="flex flex-col items-center gap-1 bg-ink-900 px-4 py-8 text-center sm:py-10"
          >
            <s.icon className="mb-2 h-6 w-6 text-gold-400" />
            <span className="font-display text-3xl font-bold text-white sm:text-4xl">
              {s.value}
            </span>
            <span className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">
              {s.label}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
