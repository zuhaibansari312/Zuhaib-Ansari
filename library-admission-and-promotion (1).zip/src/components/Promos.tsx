import { useState } from "react";
import {
  Check,
  Copy,
  FileText,
  MessageSquare,
  Share2,
  Sparkles,
} from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import { PLANS, PROMOS } from "@/data";
import { WhatsAppIcon } from "@/components/icons";
import { cn } from "@/utils/cn";

function CopyButton({ text, label = "Copy Text" }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    }
  };

  return (
    <button
      type="button"
      onClick={handleCopy}
      className={cn(
        "inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-bold transition-all sm:text-sm",
        copied
          ? "bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-400/50"
          : "bg-gold-gradient text-ink-950 shadow-md shadow-gold-900/30 hover:scale-[1.03]"
      )}
    >
      {copied ? (
        <>
          <Check className="h-4 w-4" /> Copied!
        </>
      ) : (
        <>
          <Copy className="h-4 w-4" /> {label}
        </>
      )}
    </button>
  );
}

export default function Promos() {
  const optionNumber = ["Option 1", "Option 2", "Option 3"];

  return (
    <section id="promos" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Marketing & Broadcast Sections"
          title={
            <>
              Ready-to-use{" "}
              <span className="text-gold-gradient">Promotional Sections.</span>
            </>
          }
          description="Three distinct promotional layouts ready for WhatsApp broadcasting, pamphlet distribution, or social media ads — plus a quick reference table of your library details."
        />

        {/* Section 0: Quick Structured Summary Table */}
        <div className="mt-14 overflow-hidden rounded-3xl border border-white/10 bg-ink-900">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-ink-950/60 px-6 py-4">
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gold-500/15 text-gold-400">
                <FileText className="h-5 w-5" />
              </span>
              <div>
                <h3 className="font-display text-lg font-bold text-white">
                  Structured Library Reference Summary
                </h3>
                <p className="text-xs text-slate-400">
                  Quick details table for flyers, posters &amp; counter desk
                </p>
              </div>
            </div>
            <span className="rounded-full border border-gold-500/30 bg-gold-500/10 px-3 py-1 text-xs font-semibold text-gold-300">
              55 Total Seats
            </span>
          </div>

          <div className="grid divide-y divide-white/10 lg:grid-cols-3 lg:divide-x lg:divide-y-0">
            {PLANS.map((plan) => (
              <div key={plan.id} className="p-6">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-gold-400">
                    {plan.name}
                  </span>
                  <span className="rounded-full bg-white/5 px-2.5 py-0.5 text-xs font-medium text-slate-300">
                    {plan.hours}
                  </span>
                </div>
                <p className="mt-1 font-display text-xl font-bold text-white">
                  {plan.shift}
                </p>
                <p className="mt-1 text-sm text-slate-400">{plan.timings}</p>
                <div className="mt-4 flex items-baseline justify-between border-t border-white/10 pt-4">
                  <span className="text-xs text-slate-400">Monthly Fee</span>
                  <span className="font-display text-2xl font-bold text-gold-300">
                    ₹{plan.fee}/month
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 3 Dedicated Promotional Sections */}
        <div className="mt-10 grid gap-8 lg:grid-cols-3">
          {PROMOS.map((promo, idx) => {
            const isWhatsapp = promo.id === "whatsapp";
            return (
              <article
                key={promo.id}
                className={cn(
                  "flex flex-col justify-between rounded-3xl border p-6 sm:p-7 transition-all",
                  isWhatsapp
                    ? "border-gold-500/50 bg-gradient-to-b from-ink-800 to-ink-900 shadow-2xl shadow-gold-950/40"
                    : "border-white/10 bg-ink-900"
                )}
              >
                <div>
                  {/* Header Badge */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1 text-xs font-bold uppercase tracking-wider text-gold-400">
                      <Sparkles className="h-3.5 w-3.5" />
                      {optionNumber[idx]}
                    </span>
                    <span className="rounded-full border border-gold-500/30 bg-gold-500/10 px-2.5 py-0.5 text-[11px] font-semibold text-gold-300">
                      {promo.badge}
                    </span>
                  </div>

                  <h3 className="mt-4 font-display text-2xl font-bold text-white">
                    {promo.label}
                  </h3>
                  <p className="mt-1.5 text-sm text-slate-400">
                    {promo.description}
                  </p>

                  {/* Promo Box */}
                  <div className="mt-5 rounded-2xl border border-white/10 bg-ink-950/80 p-4">
                    <pre className="max-h-72 overflow-y-auto whitespace-pre-wrap font-sans text-xs leading-relaxed text-slate-200">
                      {promo.body}
                    </pre>
                  </div>
                </div>

                {/* Footer action buttons */}
                <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-5">
                  <CopyButton
                    text={promo.body}
                    label={`Copy ${optionNumber[idx]}`}
                  />

                  {isWhatsapp ? (
                    <a
                      href={`https://wa.me/?text=${encodeURIComponent(
                        promo.body
                      )}`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-4 py-2.5 text-xs font-bold text-emerald-300 hover:bg-emerald-500/20"
                    >
                      <WhatsAppIcon className="h-4 w-4" />
                      Share on WA
                    </a>
                  ) : promo.id === "sms" ? (
                    <span className="inline-flex items-center gap-1.5 text-xs text-slate-400">
                      <MessageSquare className="h-4 w-4 text-gold-400" />
                      Ideal for Pamphlet / SMS
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 text-xs text-slate-400">
                      <Share2 className="h-4 w-4 text-gold-400" />
                      Insta / FB Ready
                    </span>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
