import type { ReactNode } from "react";
import { StarMark } from "@/components/Brand";
import { CONTACT, PLANS, type Plan } from "@/data";
import type { AdmissionFormData } from "@/hooks/useAdmissionForm";
import { cn } from "@/utils/cn";

function Line({ label, value }: { label: string; value?: string }) {
  return (
    <div className="flex flex-col">
      <span className="text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">
        {label}
      </span>
      <span className="mt-1 min-h-[1.45rem] border-b border-slate-400 pb-0.5 text-sm font-semibold text-slate-900">
        {value || "\u00A0"}
      </span>
    </div>
  );
}

function CheckRow({ options, value }: { options: string[]; value: string }) {
  return (
    <div className="flex flex-wrap gap-x-7 gap-y-1.5">
      {options.map((o) => (
        <span key={o} className="flex items-center gap-2 text-sm text-slate-900">
          <span className="flex h-4 w-4 items-center justify-center border border-slate-500">
            {value === o && <span className="h-2.5 w-2.5 bg-slate-900" />}
          </span>
          {o}
        </span>
      ))}
    </div>
  );
}

function SectionTitle({ children }: { children: ReactNode }) {
  return (
    <h3 className="mb-3 bg-slate-100 px-3 py-1.5 text-xs font-bold uppercase tracking-[0.14em] text-slate-800">
      {children}
    </h3>
  );
}

function Signature({ label }: { label: string }) {
  return (
    <div className="flex flex-col">
      <span className="h-14" />
      <span className="border-t border-slate-500 pt-1.5 text-center text-xs font-semibold text-slate-800">
        {label}
      </span>
    </div>
  );
}

interface PrintAdmissionFormProps {
  form: AdmissionFormData;
  selectedPlan: Plan | null;
}

export default function PrintAdmissionForm({
  form,
  selectedPlan,
}: PrintAdmissionFormProps) {
  const today = new Date().toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

  return (
    <div className="hidden print:block">
      <div className="mx-auto max-w-[190mm] bg-white px-8 py-10 font-sans text-slate-900">
        {/* Header */}
        <div className="flex items-start justify-between gap-6 border-b-[3px] border-slate-900 pb-5">
          <div className="flex items-center gap-3">
            <span className="flex h-14 w-14 items-center justify-center rounded-xl bg-slate-900 text-gold-300">
              <StarMark className="h-9 w-9" />
            </span>
            <div>
              <h1 className="font-display text-2xl font-bold leading-tight text-slate-900">
                GOLD STAR{" "}
                <span className="text-[#936f23]">SELF STUDY LIBRARY</span>
              </h1>
              <p className="mt-0.5 text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                Admission / Registration Form
              </p>
            </div>
          </div>
          <div className="shrink-0 text-right text-xs leading-relaxed text-slate-700">
            <p>
              <span className="font-semibold">Seat No.:</span>{" "}
              {form.seatNumber ? `#${form.seatNumber}` : "________"}
            </p>
            <p>
              <span className="font-semibold">Date:</span> {today}
            </p>
            <p className="mt-1 text-[11px] text-slate-500">
              {CONTACT.phoneDisplay} · {CONTACT.email}
            </p>
          </div>
        </div>

        {/* Student details */}
        <div className="mt-7">
          <SectionTitle>1 · Student Details</SectionTitle>
          <div className="grid grid-cols-2 gap-x-8 gap-y-5">
            <Line label="Full Student Name" value={form.fullName} />
            <Line label="Contact Number" value={form.contactNumber} />
            <Line label="Email Address" value={form.email} />
            <Line label="Guardian / Parent Name" value={form.guardianName} />
            <div className="col-span-2">
              <Line label="Residential Address" value={form.address} />
            </div>
            <Line label="City" value={form.city} />
            <Line label="Start Date" value={form.startDate} />
          </div>
        </div>

        {/* Plan */}
        <div className="mt-7">
          <SectionTitle>2 · Membership Plan Selected</SectionTitle>
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr className="border-b-2 border-slate-400 text-left text-xs uppercase tracking-wide text-slate-500">
                <th className="py-1.5 pr-2 font-semibold">Plan</th>
                <th className="py-1.5 pr-2 font-semibold">Shift</th>
                <th className="py-1.5 pr-2 font-semibold">Timings</th>
                <th className="py-1.5 text-right font-semibold">Monthly Fee</th>
              </tr>
            </thead>
            <tbody>
              {PLANS.map((p) => (
                <tr key={p.id} className="border-b border-slate-200">
                  <td className="py-1.5 pr-2">
                    <span
                      className={cn(
                        "mr-2 inline-flex h-4 w-4 items-center justify-center border border-slate-500 align-middle",
                        selectedPlan?.id === p.id && "bg-slate-900"
                      )}
                    >
                      {selectedPlan?.id === p.id && (
                        <span className="h-2.5 w-2.5 bg-white" />
                      )}
                    </span>
                    {p.name}
                  </td>
                  <td className="py-1.5 pr-2 text-slate-700">{p.shift}</td>
                  <td className="py-1.5 pr-2 text-slate-700">{p.timings}</td>
                  <td className="py-1.5 text-right font-semibold">₹{p.fee}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Seat & ID */}
        <div className="mt-7 grid grid-cols-2 gap-x-8 gap-y-5">
          <div>
            <SectionTitle>3 · Seat &amp; ID Proof</SectionTitle>
            <div className="space-y-4">
              <Line
                label="Preferred Seat Number (1 – 55)"
                value={form.seatNumber ? String(form.seatNumber) : undefined}
              />
              <div>
                <span className="mb-1.5 block text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">
                  ID Proof Type
                </span>
                <CheckRow
                  options={["Government ID", "Student ID"]}
                  value={form.idType}
                />
              </div>
              <Line label="ID Proof Number" value={form.idNumber} />
            </div>
          </div>

          <div>
            <SectionTitle>4 · Fee Summary</SectionTitle>
            <div className="space-y-3">
              <div className="flex items-end justify-between border-b border-slate-400 pb-2">
                <span className="text-sm font-medium text-slate-700">
                  Membership Fee (monthly)
                </span>
                <span className="text-lg font-bold text-slate-900">
                  {selectedPlan ? `₹${selectedPlan.fee}` : "₹______"}
                </span>
              </div>
              <div className="flex items-end justify-between border-b border-slate-400 pb-2">
                <span className="text-sm font-medium text-slate-700">
                  Amount Received
                </span>
                <span className="text-lg font-bold text-slate-900">₹______</span>
              </div>
              <div className="flex items-end justify-between border-b-2 border-slate-900 pb-2">
                <span className="text-sm font-semibold text-slate-900">
                  Balance Due
                </span>
                <span className="text-lg font-bold text-slate-900">₹______</span>
              </div>
            </div>
          </div>
        </div>

        {/* Declaration */}
        <div className="mt-7">
          <SectionTitle>5 · Declaration</SectionTitle>
          <p className="text-xs leading-relaxed text-slate-700">
            I hereby declare that the information furnished above is true and
            correct to the best of my knowledge. I agree to abide by the rules,
            timings and silence policy of Gold Star Self Study Library and
            understand that misuse of facilities may lead to cancellation of
            membership. The seat allotted is valid for the selected plan period
            only and is non-transferable.
          </p>
        </div>

        {/* Signatures */}
        <div className="mt-10 grid grid-cols-3 gap-8">
          <Signature label="Applicant's Signature" />
          <Signature label="Guardian's Signature" />
          <Signature label="For Library Use" />
        </div>

        {/* Footer */}
        <div className="mt-10 flex items-center justify-between border-t border-slate-300 pt-4 text-[11px] text-slate-500">
          <span>
            📞 {CONTACT.phoneDisplay} · ✉️ {CONTACT.email}
          </span>
          <span>This is a system-generated form.</span>
        </div>
      </div>
    </div>
  );
}
