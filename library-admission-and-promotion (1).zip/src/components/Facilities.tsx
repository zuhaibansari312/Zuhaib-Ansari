import { Armchair, Droplets, PlugZap, Snowflake, VolumeX, Wifi } from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import { FACILITIES, type Facility } from "@/data";

const ICONS: Record<Facility["icon"], typeof Wifi> = {
  ac: Snowflake,
  wifi: Wifi,
  chair: Armchair,
  power: PlugZap,
  silence: VolumeX,
  water: Droplets,
};

export default function Facilities() {
  return (
    <section id="facilities" className="relative py-20 sm:py-28">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ink-900/60 to-transparent" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="World-Class Facilities"
          title={
            <>
              Everything you need to{" "}
              <span className="text-gold-gradient">stay in the zone.</span>
            </>
          }
          description="Every amenity is included in your membership — no add-ons, no surprises."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FACILITIES.map((f) => {
            const Icon = ICONS[f.icon];
            return (
              <div
                key={f.title}
                className="group relative overflow-hidden rounded-3xl border border-white/10 bg-ink-900 p-7 transition-all duration-300 hover:-translate-y-1 hover:border-gold-500/40"
              >
                <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full gold-glow opacity-0 blur-xl transition-opacity duration-300 group-hover:opacity-100" />
                <span className="relative flex h-14 w-14 items-center justify-center rounded-2xl border border-gold-500/20 bg-gold-500/10 text-gold-400">
                  <Icon className="h-7 w-7" />
                </span>
                <h3 className="relative mt-5 font-display text-xl font-bold text-white">
                  {f.title}
                </h3>
                <p className="relative mt-2.5 text-sm leading-relaxed text-slate-400">
                  {f.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
