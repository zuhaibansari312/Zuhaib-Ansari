import { ArrowRight, Clock, Mail, MapPin, Phone } from "lucide-react";
import { CONTACT } from "@/data";
import { WhatsAppIcon } from "@/components/icons";

export default function Contact({
  onOpenAdmission,
}: {
  onOpenAdmission?: () => void;
}) {
  return (
    <section id="contact" className="relative py-14 sm:py-20">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="overflow-hidden rounded-3xl border border-gold-500/40 bg-gradient-to-r from-ink-900 via-ink-900 to-ink-950 p-6 shadow-xl sm:p-9">
          <div className="flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-center">
            {/* Left: Brand + Quick Info */}
            <div className="space-y-2">
              <span className="inline-flex items-center gap-2 rounded-full border border-gold-500/30 bg-gold-500/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-gold-300">
                Gold Star Self Study Library
              </span>
              <h2 className="font-display text-2xl font-bold text-white sm:text-3xl">
                Reserve Your Desk Today (Seat #1 to #55)
              </h2>
              <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-slate-300 sm:text-sm">
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="h-4 w-4 text-gold-400" />
                  7:00 AM – 9:00 PM (Daily)
                </span>
                <a
                  href={CONTACT.mapsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-gold-300 hover:underline"
                >
                  <MapPin className="h-4 w-4 text-gold-400" />
                  Banswara, Rajasthan (Open Map ↗)
                </a>
              </div>
            </div>

            {/* Right: Quick Action Pills */}
            <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
              <a
                href={`tel:+${CONTACT.phoneRaw}`}
                className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2.5 text-xs font-semibold text-white transition-colors hover:border-gold-400/50 hover:text-gold-200 sm:text-sm"
              >
                <Phone className="h-4 w-4 text-gold-400" />
                {CONTACT.phoneDisplay}
              </a>

              <a
                href={`https://wa.me/${CONTACT.phoneRaw}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-4 py-2.5 text-xs font-semibold text-emerald-300 transition-colors hover:bg-emerald-500/20 sm:text-sm"
              >
                <WhatsAppIcon className="h-4 w-4" />
                WhatsApp
              </a>

              <a
                href={`mailto:${CONTACT.email}`}
                className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2.5 text-xs font-semibold text-slate-200 transition-colors hover:border-gold-400/50 sm:text-sm"
              >
                <Mail className="h-4 w-4 text-gold-400" />
                Email
              </a>

              <button
                type="button"
                onClick={onOpenAdmission}
                className="group inline-flex items-center gap-2 rounded-full bg-gold-gradient px-5 py-2.5 text-xs font-bold text-ink-950 shadow-lg shadow-gold-950/40 transition-transform hover:scale-105 cursor-pointer sm:text-sm"
              >
                Open Admission Form
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
