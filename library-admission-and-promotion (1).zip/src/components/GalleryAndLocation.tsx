import { useRef, useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  MapPin,
  Maximize2,
  Navigation,
  Sparkles,
  X,
} from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import { CONTACT } from "@/data";
import hallImg from "@/assets/gallery-hall.jpg";
import cubicleImg from "@/assets/gallery-cubicle.jpg";
import entranceImg from "@/assets/gallery-entrance.jpg";
import deskImg from "@/assets/desk.jpg";

interface PhotoItem {
  id: string;
  src: string;
  title: string;
  subtitle: string;
  tag: string;
}

const PHOTOS: PhotoItem[] = [
  {
    id: "hall",
    src: hallImg,
    title: "AC Silent Study Hall",
    subtitle: "Spacious individual cubicles with warm non-glare LED lamps",
    tag: "55 Numbered Seats",
  },
  {
    id: "cubicle",
    src: cubicleImg,
    title: "Personal Partitioned Desk",
    subtitle: "Dedicated power socket + high-back ergonomic mesh chair",
    tag: "Seat Close-up",
  },
  {
    id: "entrance",
    src: entranceImg,
    title: "Library Entrance & Reception",
    subtitle: "Peaceful atmosphere & biometric / ID desk entry",
    tag: "Gold Star Campus",
  },
  {
    id: "desk",
    src: deskImg,
    title: "Deep Focus Workspace",
    subtitle: "Wide wooden tabletop for laptops, registers & reference books",
    tag: "Pin-Drop Silence",
  },
];

export default function GalleryAndLocation({
  onOpenAdmission,
}: {
  onOpenAdmission?: () => void;
}) {
  const [activePhoto, setActivePhoto] = useState<PhotoItem | null>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const sliderRef = useRef<HTMLDivElement>(null);

  const scrollToIndex = (index: number) => {
    const nextIndex = (index + PHOTOS.length) % PHOTOS.length;
    setCurrentSlide(nextIndex);
    if (sliderRef.current) {
      const child = sliderRef.current.children[nextIndex] as HTMLElement;
      child?.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
    }
  };

  const handleScroll = () => {
    if (!sliderRef.current) return;
    const scrollLeft = sliderRef.current.scrollLeft;
    const width = sliderRef.current.clientWidth;
    const index = Math.round(scrollLeft / Math.max(1, width));
    setCurrentSlide(Math.min(PHOTOS.length - 1, Math.max(0, index)));
  };

  return (
    <section id="gallery" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Library Photos & Google Map Location"
          title={
            <>
              Inside{" "}
              <span className="text-gold-gradient">Gold Star Library.</span>
            </>
          }
          description="Slide across photos of our AC self-study hall, dedicated cubicles, and visit us directly via Google Maps."
        />

        {/* Mobile Swipe/Slide Carousel Header Controls */}
        <div className="mt-8 flex items-center justify-between sm:hidden">
          <span className="inline-flex items-center gap-2 rounded-full border border-gold-500/30 bg-gold-500/10 px-3.5 py-1 text-xs font-bold text-gold-300">
            <Sparkles className="h-3.5 w-3.5" />
            Slide {currentSlide + 1} / {PHOTOS.length}
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => scrollToIndex(currentSlide - 1)}
              aria-label="Previous photo"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-ink-900 text-white active:scale-95"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => scrollToIndex(currentSlide + 1)}
              aria-label="Next photo"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-gold-gradient text-ink-950 shadow-md active:scale-95"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Mobile Slider + Desktop 4-column Grid */}
        <div
          ref={sliderRef}
          onScroll={handleScroll}
          className="mt-4 flex snap-x snap-mandatory overflow-x-auto pb-4 pt-2 sm:mt-14 sm:grid sm:grid-cols-2 sm:overflow-visible sm:pb-0 lg:grid-cols-4 sm:gap-6 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
        >
          {PHOTOS.map((photo) => (
            <div
              key={photo.id}
              className="w-full shrink-0 snap-center px-1 sm:w-auto sm:px-0"
            >
              <button
                type="button"
                onClick={() => setActivePhoto(photo)}
                className="group relative flex h-72 w-full flex-col justify-end overflow-hidden rounded-3xl border border-white/10 bg-ink-900 text-left transition-all duration-300 hover:-translate-y-1.5 hover:border-gold-500/50 hover:shadow-2xl hover:shadow-gold-950/40"
              >
                <img
                  src={photo.src}
                  alt={photo.title}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/50 to-transparent" />

                {/* Tag badge */}
                <span className="absolute left-4 top-4 inline-flex items-center gap-1.5 rounded-full border border-gold-500/30 bg-ink-950/80 px-3 py-1 text-[11px] font-semibold text-gold-300 backdrop-blur">
                  <Sparkles className="h-3 w-3 text-gold-400" />
                  {photo.tag}
                </span>

                {/* Tap to view full image helper on mobile */}
                <span className="absolute right-4 top-4 flex items-center gap-1 rounded-full bg-ink-950/75 px-2.5 py-1 text-[10px] font-semibold text-slate-200 backdrop-blur sm:h-9 sm:w-9 sm:justify-center sm:p-0 sm:opacity-0 sm:group-hover:opacity-100">
                  <Maximize2 className="h-3.5 w-3.5" />
                  <span className="sm:hidden">Full view</span>
                </span>

                {/* Caption */}
                <div className="relative p-5">
                  <h3 className="font-display text-lg font-bold text-white">
                    {photo.title}
                  </h3>
                  <p className="mt-1 text-xs leading-relaxed text-slate-300">
                    {photo.subtitle}
                  </p>
                </div>
              </button>
            </div>
          ))}
        </div>

        {/* Mobile Slide Dots Indicator */}
        <div className="mt-2 flex items-center justify-center gap-2 sm:hidden">
          {PHOTOS.map((photo, i) => (
            <button
              key={photo.id}
              type="button"
              onClick={() => scrollToIndex(i)}
              aria-label={`Go to slide ${i + 1}`}
              className={`h-2 rounded-full transition-all ${
                currentSlide === i
                  ? "w-7 bg-gold-gradient"
                  : "w-2 bg-white/20"
              }`}
            />
          ))}
        </div>

        {/* Live Google Map & Location Card */}
        <div className="mt-12 overflow-hidden rounded-3xl border border-gold-500/40 bg-gradient-to-br from-ink-900 via-ink-900 to-ink-950 shadow-2xl">
          <div className="grid lg:grid-cols-12">
            {/* Left Info */}
            <div className="flex flex-col justify-between p-7 sm:p-9 lg:col-span-5">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full border border-gold-500/30 bg-gold-500/10 px-3.5 py-1 text-xs font-bold uppercase tracking-wider text-gold-300">
                  <MapPin className="h-3.5 w-3.5" />
                  Verified Google Maps Location
                </div>

                <h3 className="mt-5 font-display text-3xl font-bold text-white">
                  Visit Gold Star Self Study Library
                </h3>

                <p className="mt-3 text-sm leading-relaxed text-slate-300">
                  Walk in for an on-the-spot tour of our 55 exclusive seats,
                  check the AC &amp; Wi-Fi speed yourself, and choose your lucky
                  desk number (#1 to #55).
                </p>

                <div className="mt-6 space-y-3 rounded-2xl border border-white/10 bg-ink-950/70 p-4 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Google Maps Pin</span>
                    <span className="font-semibold text-gold-300">
                      Gold Star Library
                    </span>
                  </div>
                  <div className="flex items-center justify-between border-t border-white/10 pt-2.5">
                    <span className="text-slate-400">City &amp; Area</span>
                    <span className="font-semibold text-white">
                      Banswara, Rajasthan
                    </span>
                  </div>
                  <div className="flex items-center justify-between border-t border-white/10 pt-2.5">
                    <span className="text-slate-400">Timings</span>
                    <span className="font-semibold text-emerald-400">
                      7:00 AM – 9:00 PM (Daily)
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href={CONTACT.mapsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="group inline-flex items-center gap-2 rounded-full bg-gold-gradient px-6 py-3.5 text-sm font-bold text-ink-950 shadow-lg shadow-gold-950/40 transition-transform hover:scale-[1.03]"
                >
                  <Navigation className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                  Open in Google Maps App
                  <ExternalLink className="h-4 w-4 opacity-75" />
                </a>
                <a
                  href={CONTACT.googleSearchUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-5 py-3.5 text-sm font-bold text-white hover:border-gold-400/50 hover:text-gold-200"
                >
                  🔍 Search &quot;Gold Star Library&quot; on Google
                </a>
                <button
                  type="button"
                  onClick={onOpenAdmission}
                  className="inline-flex items-center gap-2 rounded-full border border-white/15 px-5 py-3.5 text-sm font-bold text-white hover:border-gold-400/50 hover:text-gold-200 cursor-pointer"
                >
                  Book Seat Online
                </button>
              </div>
            </div>

            {/* Right Map Embed */}
            <div className="relative min-h-[300px] border-t border-white/10 lg:col-span-7 lg:min-h-[420px] lg:border-l lg:border-t-0">
              <iframe
                title="Gold Star Self Study Library Google Map"
                src="https://maps.google.com/maps?q=23.5704925,74.4409716&z=16&output=embed"
                className="h-full w-full border-0 grayscale-[20%] invert-[90%] hue-rotate-180 contrast-[95%]"
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
              />
              <a
                href={CONTACT.mapsUrl}
                target="_blank"
                rel="noreferrer"
                className="absolute bottom-4 right-4 inline-flex items-center gap-2 rounded-full border border-gold-500/40 bg-ink-950/90 px-4 py-2 text-xs font-bold text-gold-300 shadow-xl backdrop-blur transition-transform hover:scale-105"
              >
                <MapPin className="h-3.5 w-3.5 text-gold-400" />
                View Full Google Map →
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Fullscreen Photo Lightbox Modal */}
      {activePhoto && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md"
          onClick={() => setActivePhoto(null)}
        >
          <div
            className="relative max-w-4xl overflow-hidden rounded-3xl border border-white/15 bg-ink-900 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setActivePhoto(null)}
              className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-ink-950/80 text-white transition-colors hover:bg-gold-500 hover:text-ink-950"
            >
              <X className="h-5 w-5" />
            </button>
            <img
              src={activePhoto.src}
              alt={activePhoto.title}
              className="max-h-[75vh] w-full object-cover"
            />
            <div className="flex items-center justify-between border-t border-white/10 bg-ink-950 px-6 py-4">
              <div>
                <h4 className="font-display text-xl font-bold text-white">
                  {activePhoto.title}
                </h4>
                <p className="text-xs text-slate-400">{activePhoto.subtitle}</p>
              </div>
              <span className="rounded-full bg-gold-500/15 px-3 py-1 text-xs font-bold text-gold-300">
                {activePhoto.tag}
              </span>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
