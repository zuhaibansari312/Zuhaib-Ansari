import { useRef, useState } from "react";
import {
  ArrowRight,
  Check,
  ChevronLeft,
  ChevronRight,
  Moon,
  Sparkles,
  Sun,
  SunMoon,
} from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import { PLANS, type Plan } from "@/data";
import type { PlanId } from "@/hooks/useAdmissionForm";
import { cn } from "@/utils/cn";

const PLAN_ICONS: Record<Plan["icon"], typeof Sun> = {
  sun: Sun,
  moon: Moon,
  sunmoon: SunMoon,
};

const PERKS = [
  "Dedicated numbered desk (#1 – #55)",
  "Full AC + high-speed unlimited Wi-Fi",
  "Power outlet at your seat",
  "Purified drinking water on-premise",
];

export default function Pricing({
  onSelectPlan,
}: {
  onSelectPlan?: (id: PlanId) => void;
}) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const sliderRef = useRef<HTMLDivElement>(null);

  const scrollToIndex = (index: number) => {
    const nextIndex = (index + PLANS.length) % PLANS.length;
    setCurrentSlide(nextIndex);
    if (sliderRef.current) {
      const child = sliderRef.current.children[nextIndex] as HTMLElement;
      child?.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
        inline: "center",
      });
    }
  };

  const handleScroll = () => {
    if (!sliderRef.current) return;
    const scrollLeft = sliderRef.current.scrollLeft;
    const width = sliderRef.current.clientWidth;
    const index = Math.round(scrollLeft / Math.max(1, width));
    setCurrentSlide(Math.min(PLANS.length - 1, Math.max(0, index)));
  };

  return (
    <section id="plans" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Membership Plans"
          title={
            <>
              Flexible &amp; affordable,{" "}
              <span className="text-gold-gradient">just the way you study.</span>
            </>
          }
          description="Slide across our 3 shifts — Plan A (₹500), Plan B (₹500), or Full Day Plan C (₹900) — and tap Select to book your seat instantly."
        />

        {/* Mobile Swipe/Slide Header Controls */}
        <div className="mt-8 flex items-center justify-between sm:hidden">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-gold-500/30 bg-gold-500/10 px-3.5 py-1 text-xs font-bold text-gold-300">
            <Sparkles className="h-3.5 w-3.5" />
            {PLANS[currentSlide]?.name} ({currentSlide + 1} / {PLANS.length})
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => scrollToIndex(currentSlide - 1)}
              aria-label="Previous plan"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-ink-900 text-white active:scale-95"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => scrollToIndex(currentSlide + 1)}
              aria-label="Next plan"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-gold-gradient text-ink-950 shadow-md active:scale-95"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Mobile Swipe Slider + Desktop 3-column Grid */}
        <div
          ref={sliderRef}
          onScroll={handleScroll}
          className="mt-4 flex snap-x snap-mandatory overflow-x-auto pb-4 pt-5 sm:mt-14 sm:grid sm:grid-cols-3 sm:overflow-visible sm:pb-0 sm:gap-6 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
        >
          {PLANS.map((plan) => {
            const Icon = PLAN_ICONS[plan.icon];
            return (
              <div
                key={plan.id}
                className="w-full shrink-0 snap-center px-1.5 sm:w-auto sm:px-0"
              >
                <div
                  className={cn(
                    "relative flex h-full flex-col justify-between rounded-3xl border p-7 transition-all duration-300",
                    plan.popular
                      ? "border-gold-500/60 bg-gradient-to-b from-ink-800 to-ink-900 shadow-2xl shadow-gold-900/20 lg:-translate-y-3"
                      : "border-white/10 bg-ink-900 hover:border-gold-500/30"
                  )}
                >
                  {plan.popular && (
                    <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-gold-gradient px-4 py-1 text-xs font-bold uppercase tracking-wide text-ink-950 shadow-lg">
                      Most Popular
                    </span>
                  )}

                  <div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span
                          className={cn(
                            "flex h-12 w-12 items-center justify-center rounded-2xl",
                            plan.popular
                              ? "bg-gold-gradient text-ink-950"
                              : "bg-white/5 text-gold-400"
                          )}
                        >
                          <Icon className="h-6 w-6" />
                        </span>
                        <div>
                          <h3 className="font-display text-xl font-bold text-white">
                            {plan.name}
                          </h3>
                          <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                            {plan.shift}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-5 flex items-end gap-1">
                      <span className="font-display text-5xl font-bold text-white">
                        ₹{plan.fee}
                      </span>
                      <span className="mb-1.5 text-sm text-slate-400">
                        /month
                      </span>
                    </div>

                    <div className="mt-3 inline-flex items-center gap-2 text-sm text-slate-300">
                      <span className="rounded-md bg-white/5 px-2.5 py-1 text-xs font-medium text-gold-300">
                        {plan.timings}
                      </span>
                      <span className="rounded-md bg-white/5 px-2 py-1 text-xs text-slate-400">
                        {plan.hours}
                      </span>
                    </div>
                    <p className="mt-3 text-sm text-slate-400">
                      {plan.tagline}
                    </p>

                    <div className="my-6 hairline h-px" />

                    <ul className="space-y-3">
                      {PERKS.map((perk) => (
                        <li
                          key={perk}
                          className="flex items-center gap-2.5 text-sm text-slate-300"
                        >
                          <Check className="h-4 w-4 shrink-0 text-gold-400" />
                          {perk}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectPlan?.(plan.id)}
                    className={cn(
                      "group mt-8 inline-flex w-full items-center justify-center gap-2 rounded-full px-5 py-3.5 text-sm font-bold transition-all cursor-pointer",
                      plan.popular
                        ? "bg-gold-gradient text-ink-950 shadow-lg shadow-gold-900/30 hover:scale-[1.02]"
                        : "border border-white/15 text-white hover:border-gold-400/50 hover:text-gold-200"
                    )}
                  >
                    Select {plan.name} &amp; Open Admission Form
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Mobile Slide Dots Indicator */}
        <div className="mt-3 flex items-center justify-center gap-2 sm:hidden">
          {PLANS.map((plan, i) => (
            <button
              key={plan.id}
              type="button"
              onClick={() => scrollToIndex(i)}
              aria-label={`Go to ${plan.name}`}
              className={`h-2 rounded-full transition-all ${
                currentSlide === i
                  ? "w-8 bg-gold-gradient"
                  : "w-2 bg-white/20"
              }`}
            />
          ))}
        </div>

        <p className="mt-8 text-center text-sm text-slate-500">
          Have a group or long-term requirement?{" "}
          <a
            href="#contact"
            className="font-semibold text-gold-400 hover:text-gold-300"
          >
            Contact us for custom arrangements →
          </a>
        </p>
      </div>
    </section>
  );
}
