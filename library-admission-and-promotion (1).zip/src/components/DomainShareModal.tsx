import { useState } from "react";
import {
  Check,
  Copy,
  Download,
  ExternalLink,
  Globe,
  Share2,
  Sparkles,
  X,
} from "lucide-react";

export default function DomainShareModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [copiedDomain, setCopiedDomain] = useState<string | null>(null);

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedDomain(text);
      setTimeout(() => setCopiedDomain(null), 2000);
    } catch {
      setCopiedDomain(text);
      setTimeout(() => setCopiedDomain(null), 2000);
    }
  };

  const downloadStandaloneHtml = () => {
    const htmlContent = document.documentElement.outerHTML;
    const blob = new Blob(["<!doctype html>\n" + htmlContent], {
      type: "text/html;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "GoldStarLibrary-Official-Website.html";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const FREE_DOMAINS = [
    {
      name: "Netlify Drop (Recommended — 10 Seconds Free)",
      exampleUrl: "https://goldstarlibrary.netlify.app",
      uploadUrl: "https://app.netlify.com/drop",
      steps:
        "बटन दबाकर फाइल डाउनलोड करें → Netlify Drop पर ड्रैग/अपलोड करें → तुरंत फ्री https://goldstarlibrary.netlify.app लिंक चालू!",
    },
    {
      name: "Tiiny Host (No Signup — Instant Link)",
      exampleUrl: "https://goldstarlibrary.tiiny.site",
      uploadUrl: "https://tiiny.host",
      steps:
        "फाइल अपलोड करें → नाम में 'goldstarlibrary' लिखें → 5 सेकंड में लाइव लिंक तैयार!",
    },
    {
      name: "Vercel / GitHub Pages (Free Permanent Subdomain)",
      exampleUrl: "https://goldstarlibrary.vercel.app",
      uploadUrl: "https://vercel.com/new",
      steps:
        "फ्री Vercel अकाउंट पर प्रोजेक्ट डिप्लॉय करें और हमेशा के लिए फ्री फास्ट डोमेन पाएँ।",
    },
  ];

  return (
    <>
      {/* Floating Quick Domain / Share Pill in bottom right */}
      <div className="fixed bottom-4 left-4 z-40 print:hidden">
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className="group inline-flex items-center gap-2 rounded-full border border-gold-500/50 bg-ink-950/95 px-4 py-2.5 text-xs font-bold text-gold-300 shadow-2xl backdrop-blur-md transition-all hover:bg-gold-gradient hover:text-ink-950 cursor-pointer"
        >
          <Globe className="h-4 w-4 text-gold-400 group-hover:text-ink-950 animate-pulse" />
          <span>Get Free Live Domain / Share Link</span>
        </button>
      </div>

      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md"
          onClick={() => setIsOpen(false)}
        >
          <div
            className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-gold-500/50 bg-ink-950 p-6 shadow-2xl sm:p-8"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gold-gradient text-ink-950">
                  <Globe className="h-6 w-6" />
                </span>
                <div>
                  <h3 className="font-display text-xl font-bold text-white">
                    Temporary &amp; Free Live Domain Guide
                  </h3>
                  <p className="text-xs text-slate-400">
                    Get <strong className="text-gold-300">goldstarlibrary.netlify.app</strong> live in 10 seconds
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Step 1: Download Single File */}
            <div className="mt-5 rounded-2xl border border-gold-500/40 bg-gold-500/10 p-5">
              <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
                <div>
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-gold-300">
                    <Sparkles className="h-3.5 w-3.5" />
                    Step 1 · Single-File Website Ready
                  </span>
                  <p className="mt-1 text-sm font-semibold text-white">
                    पूरी वेबसाइट (सभी HD फोटो + फॉर्म + WhatsApp) 1 ही HTML फाइल में पैक है!
                  </p>
                </div>
                <button
                  type="button"
                  onClick={downloadStandaloneHtml}
                  className="inline-flex shrink-0 items-center gap-2 rounded-full bg-gold-gradient px-5 py-2.5 text-xs font-bold text-ink-950 shadow-lg hover:scale-105 cursor-pointer"
                >
                  <Download className="h-4 w-4" />
                  Download Website File
                </button>
              </div>
            </div>

            {/* Step 2: 3 Instant Free Hosting Domains */}
            <div className="mt-6 space-y-3.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Step 2 · 10 सेकंड में इनमें से कोई भी फ्री डोमेन चुनें:
              </h4>

              {FREE_DOMAINS.map((item) => (
                <div
                  key={item.name}
                  className="rounded-2xl border border-white/10 bg-ink-900 p-4 transition-colors hover:border-gold-500/30"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-sm font-bold text-white">
                      {item.name}
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleCopy(item.exampleUrl)}
                        className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1 text-xs font-semibold text-gold-300 hover:bg-white/10"
                      >
                        {copiedDomain === item.exampleUrl ? (
                          <>
                            <Check className="h-3.5 w-3.5 text-emerald-400" />{" "}
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="h-3.5 w-3.5" /> Copy Domain
                          </>
                        )}
                      </button>
                      <a
                        href={item.uploadUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-bold text-emerald-300 hover:bg-emerald-500/25"
                      >
                        Open Free Host <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </div>
                  <p className="mt-1 text-xs font-mono text-gold-300">
                    🌐 {item.exampleUrl}
                  </p>
                  <p className="mt-1.5 text-xs text-slate-300">{item.steps}</p>
                </div>
              ))}
            </div>

            {/* WhatsApp direct share */}
            <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-4">
              <span className="text-xs text-slate-400">
                Google Maps पर भी यही लिंक <strong>Website</strong> वाले बॉक्स में डाल सकते हैं!
              </span>
              <a
                href={`https://wa.me/918890118844?text=${encodeURIComponent(
                  "Hello Gold Star Library! Checking my website domain setup."
                )}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs font-bold text-emerald-300 hover:bg-emerald-500/20"
              >
                <Share2 className="h-3.5 w-3.5" />
                WhatsApp Support: 8890118844
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
