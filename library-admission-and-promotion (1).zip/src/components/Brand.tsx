import { cn } from "@/utils/cn";

export function StarMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true">
      <path
        d="M12 2.2l2.65 5.5 6.05.8-4.42 4.2 1.1 6.0L12 15.9l-5.38 2.8 1.1-6.0-4.42-4.2 6.05-.8L12 2.2z"
        fill="currentColor"
      />
    </svg>
  );
}

interface LogoProps {
  className?: string;
  markClassName?: string;
  compact?: boolean;
}

export function Logo({ className, markClassName, compact = false }: LogoProps) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <span
        className={cn(
          "relative flex h-10 w-10 items-center justify-center rounded-xl bg-gold-gradient text-ink-950 shadow-lg shadow-gold-900/40",
          markClassName
        )}
      >
        <StarMark className="h-6 w-6" />
        <span className="absolute inset-0 rounded-xl ring-1 ring-white/20 ring-inset" />
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="font-display text-lg font-bold tracking-wide text-white">
            GOLD STAR
          </span>
          <span className="mt-1 text-[0.65rem] font-semibold uppercase tracking-[0.22em] text-gold-400">
            Self Study Library
          </span>
        </span>
      )}
    </span>
  );
}
