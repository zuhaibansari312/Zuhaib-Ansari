import { ArrowRight, Star } from "lucide-react";
import { StarMark } from "@/components/Brand";
import { CONTACT } from "@/data";
import heroImg from "@/assets/hero.jpg";

export default function Hero({ onOpenAdmission }: { onOpenAdmission: () => void }) {
  return (
    <section id="top" className="relative min-h-[100svh] overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={heroImg}
          alt="Premium study library interior with individual desks"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/90 to-ink-950/55" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-ink-950/70" />
        <div className="absolute inset-0 bg-grid opacity-60" />
        <div className="absolute -left-24 top-1/4 h-[28rem] w-[28rem] gold-glow opacity-40 blur-2xl" />
      </div>

      <div className="relative mx-auto flex max-w-7xl flex-col justify-center px-5 pb-24 pt-32 sm:px-8 lg:min-h-[100svh] lg:pb-32 lg:pt-36">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-gold-500/30 bg-gold-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.16em] text-gold-300 backdrop-blur">
            <Star className="h-3.5 w-3.5 fill-gold-400 text-gold-400" />
            Admissions Open · 55 Exclusive Seats
          </div>

          <h1 className="mt-6 font-display text-5xl font-bold leading-[1.05] tracking-tight text-white sm:text-6xl lg:text-7xl">
            Your private space for{" "}
            <span className="text-gold-gradient">ultimate success.</span>
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-slate-300">
            Gold Star Self Study Library is a premium, pin-drop-silent study
            sanctuary — fully air-conditioned with high-speed Wi-Fi, ergonomic
            desks and a seat reserved just for you.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={onOpenAdmission}
              className="group inline-flex items-center gap-2 rounded-full bg-gold-gradient px-7 py-3.5 text-base font-bold text-ink-950 shadow-xl shadow-gold-900/40 transition-transform hover:scale-[1.03] cursor-pointer"
            >
              Reserve Your Desk
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-0.5" />
            </button>
            <a
              href="#plans"
              className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-7 py-3.5 text-base font-semibold text-white backdrop-blur transition-colors hover:border-gold-400/40 hover:text-gold-200"
            >
              Explore Plans
            </a>
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-slate-400">
            <span className="inline-flex items-center gap-2">
              <StarMark className="h-4 w-4 text-gold-400" />
              Plans from <span className="font-semibold text-white">₹500/month</span>
            </span>
            <a
              href={CONTACT.googleSearchUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-full border border-gold-500/30 bg-gold-500/10 px-3 py-1 text-xs font-semibold text-gold-300 transition-colors hover:bg-gold-500/20"
            >
              🔍 Google Search: &quot;Gold Star Library&quot;
            </a>
            <span className="inline-flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-gold-400" />
              WhatsApp: 8890118844
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
