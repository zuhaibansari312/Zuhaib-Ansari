import { useEffect } from "react";
import {
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  CreditCard,
  FileSpreadsheet,
  Info,
  Mail,
  MapPin,
  Printer,
  Sparkles,
  User,
  X,
} from "lucide-react";
import type { ReactNode } from "react";
import { BOOKED_SEATS, CONTACT, PLANS, type Plan } from "@/data";
import type { AdmissionFormData, PlanId } from "@/hooks/useAdmissionForm";
import { WhatsAppIcon } from "@/components/icons";
import { cn } from "@/utils/cn";

const inputClass =
  "w-full rounded-xl border border-white/10 bg-ink-800/60 px-4 py-3 text-sm text-white placeholder:text-slate-500 outline-none transition-colors focus:border-gold-400/60 focus:ring-2 focus:ring-gold-500/20 [color-scheme:dark]";

interface FieldProps {
  label: string;
  required?: boolean;
  children: ReactNode;
  className?: string;
}

function Field({ label, required, children, className }: FieldProps) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-2 flex items-center gap-1 text-sm font-semibold text-slate-200">
        {label}
        {required && <span className="text-gold-400">*</span>}
      </span>
      {children}
    </label>
  );
}

interface AdmissionFormProps {
  form: AdmissionFormData;
  update: (patch: Partial<AdmissionFormData>) => void;
  selectedPlan: Plan | null;
  isValid: boolean;
  whatsappMessage: string;
  gmailComposeUrl: string;
  mailtoUrl: string;
  submittedChannel: "whatsapp" | "gmail" | "both" | null;
  setSubmittedChannel: (c: "whatsapp" | "gmail" | "both" | null) => void;
  reset: () => void;
  isOpen: boolean;
  onOpen: () => void;
  onClose: () => void;
}

export default function AdmissionForm({
  form,
  update,
  selectedPlan,
  isValid,
  whatsappMessage,
  gmailComposeUrl,
  mailtoUrl,
  submittedChannel,
  setSubmittedChannel,
  reset,
  isOpen,
  onOpen,
  onClose,
}: AdmissionFormProps) {
  const seats = Array.from({ length: CONTACT.totalSeats }, (_, i) => i + 1);

  const toggleSeat = (n: number) =>
    update({ seatNumber: form.seatNumber === n ? null : n });

  const handleSendWhatsApp = () => {
    if (!isValid) return;
    setSubmittedChannel(
      submittedChannel === "gmail" ? "both" : "whatsapp"
    );
    const url = `https://wa.me/${CONTACT.phoneRaw}?text=${encodeURIComponent(
      whatsappMessage
    )}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const handleSendGmail = (useApp = false) => {
    if (!isValid) return;
    setSubmittedChannel(
      submittedChannel === "whatsapp" ? "both" : "gmail"
    );
    const url = useApp ? mailtoUrl : gmailComposeUrl;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  // Close modal on ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  // Lock body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  const availableCount = CONTACT.totalSeats - BOOKED_SEATS.length;

  return (
    <>
      {/* Section on the Page with the Admission Form Launch Button */}
      <section id="admission" className="relative py-20 sm:py-28">
        <div className="absolute inset-0 bg-grid opacity-40" />
        <div className="relative mx-auto max-w-5xl px-5 sm:px-8">
          <div className="overflow-hidden rounded-3xl border border-gold-500/40 bg-gradient-to-br from-ink-900 via-ink-900 to-ink-950 p-8 shadow-2xl sm:p-12">
            <div className="flex flex-col items-center text-center">
              <span className="inline-flex items-center gap-2 rounded-full border border-gold-500/30 bg-gold-500/10 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.16em] text-gold-300">
                <Sparkles className="h-3.5 w-3.5 text-gold-400" />
                Instant Digital &amp; Printable Admission
              </span>

              <h2 className="mt-5 font-display text-4xl font-bold leading-tight text-white sm:text-5xl">
                Ready to choose your{" "}
                <span className="text-gold-gradient">Seat #1 to #55?</span>
              </h2>

              <p className="mt-4 max-w-2xl text-base leading-relaxed text-slate-300 sm:text-lg">
                Click the button below to open the interactive Admission Form
                popup. Fill your details, pick your lucky seat (#1 to #55), and
                send your completed admission form directly to our{" "}
                <span className="font-semibold text-emerald-400">WhatsApp</span>{" "}
                or <span className="font-semibold text-red-400">Gmail</span> in
                one tap!
              </p>

              {/* Live status badge strip */}
              <div className="mt-6 flex flex-wrap items-center justify-center gap-3 text-xs font-semibold text-slate-300">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-3 py-1.5 text-emerald-300 ring-1 ring-emerald-400/30">
                  <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                  {availableCount} of {CONTACT.totalSeats} Seats Available Right Now
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1.5 text-gold-300">
                  Plan A &amp; B @ ₹500/month
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1.5 text-gold-300">
                  Plan C Full Day @ ₹900/month
                </span>
              </div>

              {/* Big Launch Button */}
              <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
                <button
                  type="button"
                  onClick={onOpen}
                  className="group inline-flex items-center gap-3 rounded-full bg-gold-gradient px-8 py-4 text-base font-bold text-ink-950 shadow-2xl shadow-gold-900/40 transition-transform hover:scale-105 active:scale-95 cursor-pointer"
                >
                  <FileSpreadsheet className="h-5 w-5" />
                  Open Admission Form &amp; Select Seat
                  <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* POPUP MODAL DIALOG */}
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/80 p-3 backdrop-blur-md sm:p-6"
          onClick={onClose}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative my-auto max-h-[92vh] w-full max-w-6xl overflow-y-auto rounded-3xl border border-gold-500/40 bg-ink-950 shadow-2xl [scrollbar-width:thin]"
          >
            {/* Modal Header Bar */}
            <div className="sticky top-0 z-20 flex items-center justify-between border-b border-white/10 bg-ink-950/95 px-6 py-4 backdrop-blur-xl sm:px-8">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gold-gradient text-ink-950 font-bold">
                  ★
                </span>
                <div>
                  <h3 className="font-display text-xl font-bold text-white">
                    Gold Star Library — Seat Admission Form
                  </h3>
                  <p className="text-xs text-slate-400">
                    Fill form &amp; send directly via WhatsApp or Gmail
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close Admission Form"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/5 text-slate-300 transition-colors hover:bg-gold-500 hover:text-ink-950"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 sm:p-8">
              <div className="grid gap-8 lg:grid-cols-5">
                {/* Left: Fields & Plan selection */}
                <div className="space-y-6 lg:col-span-3">
                  <div className="rounded-3xl border border-white/10 bg-ink-900/80 p-5 sm:p-7">
                    <div className="mb-5 flex items-center gap-3">
                      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-gold-500/15 text-gold-400">
                        <User className="h-5 w-5" />
                      </span>
                      <h4 className="font-display text-lg font-bold text-white">
                        Student Details
                      </h4>
                    </div>

                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field label="Full Student Name" required>
                        <input
                          className={inputClass}
                          placeholder="e.g. Aarav Sharma"
                          value={form.fullName}
                          onChange={(e) => update({ fullName: e.target.value })}
                        />
                      </Field>
                      <Field label="Contact Number" required>
                        <input
                          className={inputClass}
                          type="tel"
                          inputMode="numeric"
                          placeholder="10-digit mobile number"
                          value={form.contactNumber}
                          onChange={(e) =>
                            update({ contactNumber: e.target.value })
                          }
                        />
                      </Field>
                      <Field label="Email Address" className="sm:col-span-2">
                        <input
                          className={inputClass}
                          type="email"
                          placeholder="you@example.com"
                          value={form.email}
                          onChange={(e) => update({ email: e.target.value })}
                        />
                      </Field>
                      <Field label="Guardian / Parent Name">
                        <input
                          className={inputClass}
                          placeholder="Optional"
                          value={form.guardianName}
                          onChange={(e) =>
                            update({ guardianName: e.target.value })
                          }
                        />
                      </Field>
                      <Field label="Start Date">
                        <input
                          className={inputClass}
                          type="date"
                          value={form.startDate}
                          onChange={(e) =>
                            update({ startDate: e.target.value })
                          }
                        />
                      </Field>
                    </div>
                  </div>

                  <div className="rounded-3xl border border-white/10 bg-ink-900/80 p-5 sm:p-7">
                    <div className="mb-5 flex items-center gap-3">
                      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-gold-500/15 text-gold-400">
                        <CreditCard className="h-5 w-5" />
                      </span>
                      <h4 className="font-display text-lg font-bold text-white">
                        Choose Your Plan
                      </h4>
                    </div>

                    <div className="grid gap-3">
                      {PLANS.map((plan) => {
                        const active = form.plan === plan.id;
                        return (
                          <button
                            key={plan.id}
                            type="button"
                            onClick={() => update({ plan: plan.id as PlanId })}
                            className={cn(
                              "flex items-center justify-between gap-4 rounded-2xl border px-4 py-3.5 text-left transition-all",
                              active
                                ? "border-gold-500/70 bg-gold-500/10"
                                : "border-white/10 bg-ink-800/50 hover:border-gold-500/30"
                            )}
                          >
                            <div className="flex items-center gap-3.5">
                              <span
                                className={cn(
                                  "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-bold",
                                  active
                                    ? "bg-gold-gradient text-ink-950"
                                    : "bg-white/5 text-gold-300"
                                )}
                              >
                                {plan.name.replace("Plan ", "")}
                              </span>
                              <div>
                                <p className="font-semibold text-white">
                                  {plan.name} · {plan.shift}
                                </p>
                                <p className="text-xs text-slate-400">
                                  {plan.timings}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-display text-xl font-bold text-gold-300">
                                ₹{plan.fee}
                              </p>
                              <p className="text-[11px] text-slate-500">/month</p>
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    <div className="mt-5 grid gap-4 sm:grid-cols-2">
                      <Field label="ID Proof Type">
                        <select
                          className={inputClass}
                          value={form.idType}
                          onChange={(e) =>
                            update({
                              idType:
                                e.target.value as AdmissionFormData["idType"],
                            })
                          }
                        >
                          <option value="">Select ID type</option>
                          <option value="Government ID">Government ID</option>
                          <option value="Student ID">Student ID</option>
                        </select>
                      </Field>
                      <Field label="ID Proof Number">
                        <input
                          className={inputClass}
                          placeholder="ID number"
                          value={form.idNumber}
                          onChange={(e) => update({ idNumber: e.target.value })}
                        />
                      </Field>
                      <Field label="Address" className="sm:col-span-2">
                        <input
                          className={inputClass}
                          placeholder="House / Street / Area"
                          value={form.address}
                          onChange={(e) => update({ address: e.target.value })}
                        />
                      </Field>
                      <Field label="City">
                        <input
                          className={inputClass}
                          placeholder="Your city"
                          value={form.city}
                          onChange={(e) => update({ city: e.target.value })}
                        />
                      </Field>
                    </div>
                  </div>
                </div>

                {/* Right: 55-Seat Map + Summary & Send via WhatsApp/Gmail buttons */}
                <div className="lg:col-span-2">
                  <div className="space-y-6">
                    <div className="rounded-3xl border border-white/10 bg-ink-900/80 p-5 sm:p-6">
                      <div className="mb-4 flex items-center justify-between">
                        <h4 className="font-display text-lg font-bold text-white">
                          Pick Your Seat
                        </h4>
                        <span className="rounded-full bg-white/5 px-3 py-1 text-xs font-medium text-slate-400">
                          1 – {CONTACT.totalSeats}
                        </span>
                      </div>

                      <div className="grid grid-cols-5 gap-1.5 sm:grid-cols-11">
                        {seats.map((n) => {
                          const booked = BOOKED_SEATS.includes(n);
                          const selected = form.seatNumber === n;
                          return (
                            <button
                              key={n}
                              type="button"
                              disabled={booked}
                              onClick={() => toggleSeat(n)}
                              title={
                                booked ? `Seat ${n} — Booked` : `Seat ${n}`
                              }
                              className={cn(
                                "relative flex h-9 items-center justify-center rounded-md text-xs font-semibold transition-all",
                                booked
                                  ? "cursor-not-allowed bg-white/[0.03] text-slate-600"
                                  : selected
                                    ? "bg-gold-gradient text-ink-950 shadow-md shadow-gold-900/30"
                                    : "border border-white/10 bg-ink-800 text-slate-300 hover:border-gold-400/60 hover:text-gold-200"
                              )}
                            >
                              {booked ? (
                                <span className="h-px w-4 bg-slate-600" />
                              ) : (
                                n
                              )}
                            </button>
                          );
                        })}
                      </div>

                      <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-slate-400">
                        <span className="inline-flex items-center gap-1.5">
                          <span className="h-3 w-3 rounded border border-white/15 bg-ink-800" />
                          Available
                        </span>
                        <span className="inline-flex items-center gap-1.5">
                          <span className="h-3 w-3 rounded bg-gold-gradient" />
                          Selected
                        </span>
                        <span className="inline-flex items-center gap-1.5">
                          <span className="h-3 w-3 rounded bg-white/[0.03] ring-1 ring-white/10" />
                          Booked
                        </span>
                      </div>
                    </div>

                    {/* Summary & One-Click Send to WhatsApp OR Gmail */}
                    <div className="rounded-3xl border border-gold-500/40 bg-gradient-to-b from-ink-800 to-ink-900 p-5 sm:p-6 shadow-xl">
                      <div className="flex items-center justify-between">
                        <h4 className="font-display text-lg font-bold text-white">
                          Submit Application
                        </h4>
                        <span className="rounded-full bg-gold-500/15 px-2.5 py-0.5 text-[11px] font-bold text-gold-300">
                          Instant Dispatch
                        </span>
                      </div>

                      <dl className="mt-4 space-y-2.5 text-sm">
                        <div className="flex items-center justify-between gap-4">
                          <dt className="flex items-center gap-2 text-slate-400">
                            <User className="h-4 w-4 text-gold-400" />
                            Student
                          </dt>
                          <dd className="font-medium text-white truncate max-w-[170px]">
                            {form.fullName || "Enter name"}
                          </dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                          <dt className="flex items-center gap-2 text-slate-400">
                            <CalendarDays className="h-4 w-4 text-gold-400" />
                            Plan
                          </dt>
                          <dd className="text-right font-medium text-white">
                            {selectedPlan
                              ? `${selectedPlan.name} · ${selectedPlan.timings}`
                              : "Not selected"}
                          </dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                          <dt className="flex items-center gap-2 text-slate-400">
                            <MapPin className="h-4 w-4 text-gold-400" />
                            Seat No.
                          </dt>
                          <dd className="font-medium text-white">
                            {form.seatNumber
                              ? `Seat #${form.seatNumber}`
                              : "Not selected"}
                          </dd>
                        </div>
                        <div className="flex items-center justify-between gap-4 border-t border-white/10 pt-3">
                          <dt className="text-slate-300">Monthly Fee</dt>
                          <dd className="font-display text-2xl font-bold text-gold-300">
                            {selectedPlan ? `₹${selectedPlan.fee}` : "—"}
                          </dd>
                        </div>
                      </dl>

                      {/* Primary Submission Action Buttons: WhatsApp & Gmail */}
                      <div className="mt-5 space-y-2.5">
                        {/* 1. Send via WhatsApp to 8890118844 */}
                        <button
                          type="button"
                          onClick={handleSendWhatsApp}
                          disabled={!isValid}
                          className={cn(
                            "group flex w-full items-center justify-center gap-2.5 rounded-full px-5 py-3.5 text-sm font-bold transition-all cursor-pointer",
                            isValid
                              ? "bg-emerald-500 text-ink-950 shadow-lg shadow-emerald-950/40 hover:bg-emerald-400 hover:scale-[1.02]"
                              : "cursor-not-allowed bg-white/10 text-slate-500"
                          )}
                        >
                          <WhatsAppIcon className="h-5 w-5" />
                          Send Form to WhatsApp (8890118844)
                          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                        </button>

                        {/* 2. Send via Gmail (Opens Web Gmail Composer with Form pre-filled) */}
                        <button
                          type="button"
                          onClick={() => handleSendGmail(false)}
                          disabled={!isValid}
                          className={cn(
                            "group flex w-full items-center justify-center gap-2.5 rounded-full px-5 py-3.5 text-sm font-bold transition-all cursor-pointer",
                            isValid
                              ? "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-950/40 hover:from-red-400 hover:to-rose-500 hover:scale-[1.02]"
                              : "cursor-not-allowed bg-white/10 text-slate-500"
                          )}
                        >
                          <Mail className="h-5 w-5" />
                          Send Form via Gmail ({CONTACT.email})
                          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                        </button>

                        {/* 3. Print / Download A4 Form */}
                        <button
                          type="button"
                          onClick={() => window.print()}
                          className="flex w-full items-center justify-center gap-2 rounded-full border border-white/15 px-5 py-2.5 text-xs font-bold text-white transition-colors hover:border-gold-400/50 hover:text-gold-200"
                        >
                          <Printer className="h-4 w-4 text-gold-400" />
                          Print / Save PDF Copy
                        </button>

                        <button
                          type="button"
                          onClick={reset}
                          className="w-full text-center text-xs font-medium text-slate-500 transition-colors hover:text-slate-300"
                        >
                          Clear form
                        </button>
                      </div>

                      {!isValid && (
                        <p className="mt-3 flex items-start gap-2 text-xs leading-relaxed text-slate-500">
                          <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-gold-400" />
                          Fill Student Name, Contact Number, select a Plan and
                          pick a Seat number to unlock direct WhatsApp &amp; Gmail
                          sending.
                        </p>
                      )}

                      {submittedChannel && (
                        <div className="mt-3 flex items-start gap-3 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-3.5 text-xs text-emerald-200">
                          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                          <p>
                            {submittedChannel === "whatsapp" &&
                              "WhatsApp opened ready to send to 8890118844! Just tap Send in WhatsApp to confirm your seat."}
                            {submittedChannel === "gmail" &&
                              `Gmail composer opened addressed to ${CONTACT.email} with your full admission form!`}
                            {submittedChannel === "both" &&
                              "Application sent/opened in both WhatsApp (8890118844) & Gmail!"}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
