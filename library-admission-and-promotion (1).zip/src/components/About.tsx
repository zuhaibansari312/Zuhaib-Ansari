import { CheckCircle2, Sparkles } from "lucide-react";
import deskImg from "@/assets/desk.jpg";

const POINTS = [
  "55 numbered, dedicated personal desks",
  "3 affordable membership plans to fit your routine",
  "Fully air-conditioned with high-speed unlimited Wi-Fi",
  "Ergonomic chairs & a power outlet at every seat",
  "Strict pin-drop silence policy for deep focus",
];

export default function About() {
  return (
    <section className="relative overflow-hidden py-20 sm:py-28">
      <div className="absolute -right-32 top-0 h-[26rem] w-[26rem] gold-glow opacity-20 blur-2xl" />
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-2">
        <div className="relative order-2 lg:order-1">
          <div className="absolute -inset-4 -z-10 rounded-3xl bg-gradient-to-tr from-gold-500/15 to-transparent blur-2xl" />
          <div className="overflow-hidden rounded-3xl border border-white/10 shadow-2xl shadow-black/50">
            <img
              src={deskImg}
              alt="Premium ergonomic study desk with warm lighting"
              className="h-full w-full object-cover"
            />
          </div>
          <div className="absolute -bottom-5 -right-3 rounded-2xl border border-white/10 bg-ink-800/95 px-5 py-4 shadow-xl backdrop-blur sm:-right-6">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gold-gradient text-ink-950">
                <Sparkles className="h-5 w-5" />
              </span>
              <div>
                <p className="font-display text-lg font-bold text-white">
                  Built for focus
                </p>
                <p className="text-xs text-slate-400">
                  Premium, calm &amp; distraction-free
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="order-1 lg:order-2">
          <span className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-gold-400">
            <span className="h-px w-6 bg-gold-500/60" />
            Why Gold Star
          </span>
          <h2 className="mt-4 font-display text-4xl font-bold leading-tight tracking-tight text-white sm:text-5xl">
            A sanctuary engineered for{" "}
            <span className="text-gold-gradient">serious students.</span>
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-slate-400">
            Every desk, chair and corner of our library is designed to remove
            distractions and help you perform at your peak — whether you're
            preparing for board exams, competitive tests or professional
            certifications.
          </p>

          <ul className="mt-8 space-y-3.5">
            {POINTS.map((point) => (
              <li key={point} className="flex items-start gap-3">
                <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-gold-400" />
                <span className="text-slate-200">{point}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
