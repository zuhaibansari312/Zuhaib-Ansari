import { Mail, Phone } from "lucide-react";
import { Logo } from "@/components/Brand";
import { CONTACT } from "@/data";
import { WhatsAppIcon } from "@/components/icons";

const LINKS = [
  { label: "Plans", href: "#plans" },
  { label: "Photos & Map", href: "#gallery" },
  { label: "Facilities", href: "#facilities" },
  { label: "Admission Form", href: "#admission" },
  { label: "Promo Kit", href: "#promos" },
  { label: "Contact", href: "#contact" },
];

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-ink-950">
      <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <Logo />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-slate-400">
              A premium, pin-drop-silent self study library with 55 exclusive
              desks — fully air-conditioned with high-speed Wi-Fi, ergonomic
              seating and everything you need to focus.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wide text-white">
              Quick Links
            </h4>
            <ul className="mt-4 space-y-2.5">
              {LINKS.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="text-sm text-slate-400 transition-colors hover:text-gold-300"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold uppercase tracking-wide text-white">
              Get in Touch
            </h4>
            <ul className="mt-4 space-y-3">
              <li>
                <a
                  href={`tel:+${CONTACT.phoneRaw}`}
                  className="inline-flex items-center gap-2.5 text-sm text-slate-400 transition-colors hover:text-gold-300"
                >
                  <Phone className="h-4 w-4 text-gold-400" />
                  {CONTACT.phoneDisplay}
                </a>
              </li>
              <li>
                <a
                  href={`https://wa.me/${CONTACT.phoneRaw}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2.5 text-sm text-slate-400 transition-colors hover:text-emerald-300"
                >
                  <WhatsAppIcon className="h-4 w-4 text-emerald-400" />
                  WhatsApp Us
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${CONTACT.email}`}
                  className="inline-flex items-center gap-2.5 break-all text-sm text-slate-400 transition-colors hover:text-gold-300"
                >
                  <Mail className="h-4 w-4 shrink-0 text-gold-400" />
                  {CONTACT.email}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-slate-500 sm:flex-row">
          <p>© {new Date().getFullYear()} Gold Star Library (Search keyword: <strong className="text-gold-300">goldstarlibrary</strong>). All rights reserved.</p>
          <p className="flex items-center gap-1.5">
            <span className="text-gold-400">★</span> Google Search: <strong className="text-white">goldstarlibrary</strong> · WhatsApp: 8890118844
          </p>
        </div>
      </div>
    </footer>
  );
}
